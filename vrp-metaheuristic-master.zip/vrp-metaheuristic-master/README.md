## KO++ repository

This repository contains all stuff related to KO++,
including the <b>Traveling Salesman Problem</b>
(TSP) and the <b>Vehicle Routing Problem</b> (VRP).
In the "instances/" directory, multiple instances for both the TSP and VRP are provided.
Moreover, for both problems, the "src/" directory contains 
an instance representation including an instance reader.
Additionally, demo executables are given for both problems.
