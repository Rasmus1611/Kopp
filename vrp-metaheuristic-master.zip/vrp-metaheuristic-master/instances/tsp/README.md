## Instance format TSP

An instance with `n` nodes is given by a file with `n+1` lines:

- The first line contains one integer, namely the number of nodes `n`
- The next `n` lines describe the cost matrix, i.e., each line corresponds to a node and contains `n` integer values describing the travel costs to all other nodes, including itself

Numbers in instances files are separated using whitespace characters.

The following table lists optimal objective values for each given instance.

| Instance  | Optimal objective value |
|:---------:|:-----------------------:|
| a280      |          2579           | 
| berlin52  |          7542           |
| bier127   |         118282          |
| brazil58  |          25395          |
| eil51     |           426           | 
| fl1400    |          20127          |
| fri26     |           937           |
| kroA100   |          21282          |
| pa561     |          2763           |
| rat575    |          6773           |
| swiss42   |          1273           |

For more details on the instance, see <http://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/>.