#pragma once

#include <string>
#include <vector>

#include "util/Logger.hpp"
#include "util/Matrix.hpp"

namespace ko::tsp {
/**
 * A TSP instance containing the number of nodes and the travel costs between these nodes.
 */
class Instance : public Logger {
public:
    /// Ids for the nodes
    using NodeId = std::uint32_t;
    /// Travel costs values
    using TravelCost = std::int32_t;

    /**
     * Constructs an instance from a given instance file.
     *
     * @param filename Path to the instance file.
     */
    explicit Instance(const std::string& filename);

    /**
     * Destructor for the instance.
     */
    ~Instance() override = default;

    /**
     * Get the name of the instance.
     *
     * @return The filename of the instance
     */
    [[nodiscard]] std::string getFilename() const { return m_filename; }

    /**
     * Get the number of nodes.
     *
     * @return The number of nodes
     */
    [[nodiscard]] NodeId getNumberNodes() const { return m_numberNodes; }

    /**
     * Get the travel costs between two nodes.
     *
     * @param nodeFirstId The first node's id
     * @param nodeSecondId The second node's id
     * @return The travel cost between the given two nodes
     */
    [[nodiscard]] TravelCost getTravelCost(NodeId nodeFirstId, NodeId nodeSecondId) const {
        return m_travelCosts(nodeFirstId, nodeSecondId);
    }

private:
    /// Filename of the instance file
    std::string m_filename;

    /// Number of nodes
    NodeId m_numberNodes;

    /// Matrix with travel costs between nodes
    Matrix<TravelCost> m_travelCosts;
};
} // namespace ko::tsp