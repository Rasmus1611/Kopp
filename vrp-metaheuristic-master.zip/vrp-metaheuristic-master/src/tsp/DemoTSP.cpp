#include <iostream>
#include <string>

#include "tsp/Instance.hpp"
#include "util/Logger.hpp"

int main(int argc, char** argv) {
    // Create the logging object
    auto log = ko::Logger("DemoTSP");

    // Check the command line arguments
    if (argc != 2) {
        log.ERROR("usage: ./demoTSP <instance-path>");
        return EXIT_FAILURE;
    }

    // Get the instance file path
    const auto filename = std::string(argv[1]);

    // Read the given instance
    const auto instance = ko::tsp::Instance(filename);
    log.INFO("Got TSP instance with n={} nodes.", instance.getNumberNodes());

    // Prints the travel cost matrix
    log.INFO("The travel cost matrix looks as follows:");
    for (auto nodeFirstId = ko::tsp::Instance::NodeId(0); nodeFirstId < instance.getNumberNodes(); nodeFirstId++) {
        for (auto nodeSecondId = ko::tsp::Instance::NodeId(0); nodeSecondId < instance.getNumberNodes();
             nodeSecondId++) {
            std::cout << instance.getTravelCost(nodeFirstId, nodeSecondId) << " ";
        }
        std::cout << std::endl;
    }

    // Return success
    return EXIT_SUCCESS;
}