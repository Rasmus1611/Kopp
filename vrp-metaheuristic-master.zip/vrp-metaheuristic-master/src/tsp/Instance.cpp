#include <fstream>

#include "Instance.hpp"

namespace ko::tsp {

Instance::Instance(const std::string& filename)
  : Logger("Instance")
  , m_filename(filename)
  , m_numberNodes()
  , m_travelCosts() {
    // Open the file for reading
    std::ifstream ifs(filename);

    // Check if the input stream was created properly
    if (!ifs) {
        ERROR("Error when opening the file {}.", filename);
        std::exit(EXIT_FAILURE);
    }

    // Reads the number of nodes n
    if (!(ifs >> m_numberNodes)) {
        ERROR("Error while reading the number of nodes.");
        std::exit(EXIT_FAILURE);
    }

    // Reads the travel cost matrix
    m_travelCosts = Matrix<TravelCost>(m_numberNodes, m_numberNodes);
    for (auto nodeFirstId = NodeId(0); nodeFirstId < m_numberNodes; nodeFirstId++) {
        for (auto nodeSecondId = NodeId(0); nodeSecondId < m_numberNodes; nodeSecondId++) {
            if (!(ifs >> m_travelCosts(nodeFirstId, nodeSecondId))) {
                ERROR("Error while reading from file.");
                std::exit(EXIT_FAILURE);
            }
        }
    }
}

} // namespace ko::tsp