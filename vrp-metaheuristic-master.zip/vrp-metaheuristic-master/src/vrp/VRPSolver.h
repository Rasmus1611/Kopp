/**
* @file VRPSolver.h
* @brief Vereint Methoden zur Lösung von Instanz des VRP
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-14
 */

#pragma once

#include "vrp/Clustering/ClusterSolver.h"
#include "vrp/Clustering/HierarchicalClusterSolver.hpp"
#include "vrp/Clustering/KMeansClusterSolver.hpp"
#include "vrp/TSP/TSPSolver.h"
#include "vrp/TSP/TSPSolverHeuristic.h"
#include "vrp/TSP/TSPSolverDP.h"

namespace ko::vrp {

class VRPSolver : public Logger {
private:
    const Instance& m_instance;
    Solution m_solution;

    std::unique_ptr<ClusterSolver> m_clusterSolver;
    std::unique_ptr<TSPSolver> m_tspSolver;

    /**
     *  Wenn durchschnittliche Cluster-Größe >= TSP_THRESHOLD, nutze TSPSolverHeuristic, sonst nutze TSPSolverDP
     */
    const Instance::NodeId TSP_THRESHOLD = 22;

    /**
     * @brief Startet den ClusterSolver (m_clusterSolver)
     * @return true wenn der ClusterSolver eine zulässige Lösung gefunden hat, false sonst
     */
    bool runClusterSolver();

public:
    /// Constructor
    VRPSolver(const Instance& instance, std::unique_ptr<ClusterSolver> clusterSolver)
      : Logger("VRPSolver"), m_instance(instance), m_solution(Solution(instance)), m_clusterSolver(std::move(clusterSolver)) {};

    /// Destructor
    ~VRPSolver() override = default;

    /**
     * @brief Löst das VRP-Problem mit gegebenem ClusterSolver und das TSP mit Heuristik oder exakt (basierend auf TSP_THRESHOLD)
     * @return Lösung (ggf. ohne Routen, wenn ClusterSolver nicht erfolgreich war)
     */
    Solution solve(bool useImprovement);
};

} // namespace ko::vrp
