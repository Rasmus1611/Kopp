#include "Clustering/ClusterImprovement.h"
#include "VRPSolver.h"
#include "util/Logger.hpp"
#include "util/Timer.hpp"
#include "vrp/Clustering/BinPackingClusterSolver.h"
#include "vrp/Instance.hpp"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <vector>
#include <ctime>
#include <chrono>

void writeToFile(const std::string& filename, const std::string& content, bool endline) {
    // Öffne (oder erstelle) die Datei im Append-Modus
    std::ofstream file;
    file.open("./results/"+filename, std::ios::app);

    // Überprüfe, ob die Datei erfolgreich geöffnet wurde
    if (file.is_open()) {
        file << content; // Schreibe den String in die Datei
        if (endline)
            file << std::endl;
        file.close(); // Schließe die Datei
//        std::cout << "in datei geschrieben " << std::endl;
    } else {
        std::cerr << "Fehler beim Öffnen der Datei!" << std::endl;
    }
}

void printSolution(const ko::vrp::Instance& instance, const int iteration, const ko::vrp::Solution& solution) {

    const std::string filename = instance.getFileBasename();

    // write meta-data
    writeToFile(filename, filename + ";", false);
    writeToFile(filename, std::to_string(iteration) + ";", false);

    writeToFile(filename, solution.print() + ";", false);

    writeToFile(filename, solution.getClustersAsString(), true);

}

void testrun(const ko::vrp::Instance& instance, const int RUNS, bool IMPROVEMENT_ACTIVATED) {
    auto log = ko::Logger("TestRunLogger");
    log.setLogLevel(ko::LOG_LEVEL_INFO);

    const std::string filename = instance.getFileBasename();

    std::string improvementText = "(Improvement ";
    if (IMPROVEMENT_ACTIVATED)
        improvementText += "aktiviert)";
    else
        improvementText += "deaktiviert)";


    ko::Timer overallTimer;
    // Führe 100 Durchläufe durch
    for (int i = 0; i < RUNS; ++i) {

        // Get the current time
        time_t now = time(0);

        // Convert the current time to a tm structure
        tm* now_tm = localtime(&now);

        // Define a buffer to hold the formatted string
        char buffer[80];

        // Format the time into the buffer without a newline character
        strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", now_tm);

        // Convert the C-style string to a std::string
        std::string info(buffer);

        info.append("  Run " + std::to_string(i + 1) + " " + improvementText);
        log.INFO(info);

        ko::Timer currentTimerAllValues;

        // Starte VRPSolver mit KMeans
        ko::vrp::VRPSolver vrpSolverKmeans(instance, std::make_unique<ko::vrp::KmeansClusterSolver>(instance));
        ko::vrp::Solution solutionKmeans = vrpSolverKmeans.solve(IMPROVEMENT_ACTIVATED);

        // Starte VRPSolver mit Hierarchical
        ko::vrp::VRPSolver vrpSolverHierarchical(instance, std::make_unique<ko::vrp::HierarchicalClusterSolver>(instance));
        ko::vrp::Solution solutionHierarchical = vrpSolverHierarchical.solve(IMPROVEMENT_ACTIVATED);

        // Ermittle in diesem Lauf die beste Lösung:
        ko::vrp::Solution currentSolution(instance);
        if (!solutionKmeans.isFeasible() && !solutionHierarchical.isFeasible()) {
            // Wenn beide unzulässig sind, verwende BinPacking
            ko::vrp::VRPSolver vrpSolverBinPacking(instance, std::make_unique<ko::vrp::BinPackingClusterSolver>(instance));
            ko::vrp::Solution solutionBinPacking = vrpSolverBinPacking.solve(IMPROVEMENT_ACTIVATED);
//            log.INFO("BinPacking -> von beiden keine gültige Lösung. total: " + std::to_string(solutionBinPacking.getTotalTravelCost()));
            solutionBinPacking.setIsBestSolution(true);
            printSolution(instance, i+1, solutionBinPacking);

        } else if (!solutionKmeans.isFeasible()) {
//            log.INFO("Kmeans ist ungültig -> Hierarchical ist besser");
            solutionHierarchical.setIsBestSolution(true);

        } else if (!solutionHierarchical.isFeasible()) {
//            log.INFO("Hierarchical ist ungültig -> KMeans ist besser");
            solutionKmeans.setIsBestSolution(true);
        } else {
            // Beide Lösungen sind zulässig
            if (solutionKmeans.getTotalTravelCost() < solutionHierarchical.getTotalTravelCost()) {
//                log.INFO("Kmeans ist besser");
                solutionKmeans.setIsBestSolution(true);
            } else if (solutionHierarchical.getTotalTravelCost() < solutionKmeans.getTotalTravelCost()) {
//                log.INFO("Hierarchical ist besser");
                solutionHierarchical.setIsBestSolution(true);
            } else {
//                log.INFO("beide gleich gut");
                solutionKmeans.setIsBestSolution(true);
                solutionHierarchical.setIsBestSolution(true);
            }
        }

        printSolution(instance, i+1, solutionKmeans);
        printSolution(instance, i+1, solutionHierarchical);

    }
}

int main(int argc, char** argv) {
    auto start = std::chrono::high_resolution_clock::now();

    // Erstelle ein Logger-Objekt
    auto log = ko::Logger("DemoVRP");

    ko::Logger::setGlobalLogLevel(ko::LOG_LEVEL_OFF);

    // Überprüfe, ob die richtige Anzahl an Argumenten übergeben wurde
    if (argc != 2) {
        log.ERROR("usage: ./demoVRP <instance-path>");
        return EXIT_FAILURE;
    }

    // Lade die VRP-Instanz
    const auto filename = std::string(argv[1]);
    std::cout << "Loading file " << filename << std::endl;
    const auto instance = ko::vrp::Instance(filename);

    // Tightness ausgeben
    instance.printTightness();



   //writeToFile(instance.getFileBasename(), "Instanz;Iteration;Zielfunktionswert;ClusterSolver;DauerClustering;ImprovementUsed;ImprovementValue;DauerImprovement;DauerTSP;isBestSolution;Routen", true);


    //testrun(instance, 100, true);
      testrun(instance, 1, true);




//    bestSolution.plot(false, false);





    auto end = std::chrono::high_resolution_clock::now();

    const auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    std::cout << "Elapsed time: " << elapsed.count()/1000000 << " seconds\n";

    return EXIT_SUCCESS;
}
