#include "Solution.h"
#include "vrp/Clustering/ClusterSolver.h"
#include <fstream>

namespace ko::vrp {

void Solution::addCluster(const Instance::Cluster& cluster) {
    Route route;
    route.cluster = cluster;

    m_routes.push_back(route);
}


Instance::TravelCost Solution::getTotalTravelCost() const {
    Instance::TravelCost totalCost = 0;
    for (const Route& route : m_routes) {
        totalCost += route.travelCost;
    }
    return totalCost;
}
void Solution::setRoutes(const std::vector<Route>& routes) {
    m_routes.clear();
    m_routes.resize(routes.size());
    std::copy(routes.begin(), routes.end(), m_routes.begin());
}
std::string Solution::print() const {
    Logger log;


    log.INFO("SOLUTION:");
    for (size_t i = 0; i < m_routes.size(); ++i) {
        const Solution::Route& route = m_routes[i];

        log.INFO("Cluster #" + std::to_string(i+1)
             + " (size " + std::to_string(route.cluster.size())
             + "): " + Instance::toString(route.cluster)
        );
        log.INFO("TravelCost: " + std::to_string(route.travelCost));

        log.INFO("TotalDemand: " + std::to_string(route.totalDemand));
        if (route.totalDemand > m_instance->getVehicleCapacity())
            log.ERROR("Total demand higher than vehicle capacity (" + std::to_string(m_instance->getVehicleCapacity()) + ")!");

    }

    const std::string zielfunktionswert = std::to_string(this->getTotalTravelCost());

    const std::string dauerCluster = std::to_string(m_durationClustering);
    const std::string dauerImprovement = std::to_string(m_durationImprovement);
    const std::string dauerTSP = std::to_string(m_durationTSP);
    const std::string gesamtdauer = std::to_string(m_durationClustering + m_durationImprovement + m_durationTSP);

    const std::string improvementUsed = m_improvementUsed ? "1" : "0";
    const std::string improvementValue = std::to_string(m_improvementValue);
    std::string clusterSolver;
    switch (m_clusterSolver) {
        case ClusterSolverEnum::KMeans:
            clusterSolver = "KMeans";
            break;
        case ClusterSolverEnum::Hierarchical:
            clusterSolver = "Hierarchical";
            break;
        case ClusterSolverEnum::BinPacking:
            clusterSolver = "BinPacking";
            break;
        default:
            clusterSolver = "nicht gesetzt";
            break;
    }
    const std::string isBestSolution = std::to_string(m_isBestSolution);

    const std::string title =
      "Zielfunktionswert;"
      "ClusterSolver;"
      "DauerClustering;"
      "ImprovementUsed;"
      "ImprovementValue;"
      "DauerImprovement;"
      "DauerTSP;"
      "isBestSolution;";
    log.INFO(title);

    const std::string result =
      zielfunktionswert + ";"
      + clusterSolver + ";"
      + dauerCluster + ";"
      + improvementUsed + ";"
      + improvementValue + ";"
      + dauerImprovement + ";"
      + dauerTSP + ";"
      + isBestSolution;

    log.INFO(result);
    return result;

}
bool Solution::isFeasible() const {
    if (m_routes.size() > m_instance->getNumberVehicles())
        return false;

    for (const Route& route : m_routes) {
        if (m_instance->getVehicleCapacity() < ClusterSolver::computeClusterDemand(*m_instance, route.cluster))
            return false;
    }

    return true;
}
std::string Solution::getClustersAsString() const {
    std::string result;
    for (const Route& route : this->m_routes) {
        result += "{" + Instance::toString(route.cluster) + "}";
    }
    return result;
}
Solution::Solution(const Instance& instance, const std::string& filename): m_instance(&instance) {
    std::ifstream ifs(filename);
    Logger log("SolutionLogger");

    if (!ifs) {
        log.ERROR("Error when opening the file {}.", filename);
        std::exit(EXIT_FAILURE);
    }

    char character;
    // read each cluster
    while (ifs >> character) {
        if (character != '{') {
            log.ERROR("Error when reading '{'.");
            std::exit(EXIT_FAILURE);
        }

        Instance::Cluster cluster;
        Instance::TravelCost clusterTravelCost = 0;
        Instance::NodeId nodeId;


        // read each node in the cluster
        while (ifs >> nodeId) {
            if (!cluster.empty()) {
                Instance::NodeId previousNodeId = cluster.back();
                clusterTravelCost += instance.getTravelCost(previousNodeId, nodeId);
            }
            cluster.emplace_back(nodeId);

            ifs >> character;
            if (character == ',')
                continue;
            else if (character == '}')
                break;
            else {
                log.ERROR("Error when reading ',' or '}'.");
                std::exit(EXIT_FAILURE);
            }
        }
        // no nodeId read, either eof or new cluster begins

        ifs.clear();

        // compute cost from depot to first node and from last node back to depot
        clusterTravelCost += instance.getTravelCost(instance.getDepotNodeId(), cluster.front());
        clusterTravelCost += instance.getTravelCost(cluster.back(), instance.getDepotNodeId());

        log.INFO("Read cluster: " + Instance::toString(cluster));
        Route route;
        route.cluster = cluster;
        route.totalDemand = ClusterSolver::computeClusterDemand(instance, cluster);
        route.travelCost = clusterTravelCost;

        m_routes.emplace_back(route);
    }

    log.INFO("Fertig mit einlesen");


}

} // namespace ko::vrp
