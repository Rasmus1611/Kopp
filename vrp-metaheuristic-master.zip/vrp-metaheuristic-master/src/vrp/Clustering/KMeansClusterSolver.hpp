/**
* @file KMeansClusterSolver.hpp
* @brief Implementierung des KMeans Clustering für das VRP
*
* Basierend auf dem Paper "An Efficient k-Means Clustering Algorithm: Analysis and Implementation" von Tapas Kanungo, David M. Mount, Nathan S. Netanyahu, Christine D. Piatko, Ruth Silverman und Angela Y. Wu
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-12
*/


#pragma once

#include "ClusterSolver.h"
#include "vrp/Instance.hpp"
#include "vrp/Solution.h"
#include <vector>

namespace ko::vrp {

/**
 * @brief KmeansClusterSolver löst das Clustering Problem
 */
class KmeansClusterSolver : public ClusterSolver {
public:

    explicit KmeansClusterSolver(const Instance& instance)
      : ClusterSolver(instance, "Kmeans ClusterSolver") {};

    /**
     * @brief Löst das gegebene VRP-Problem durch Clustering
     * @return Solution Lösung der Instanz mit erzeugten Clustern
     */
    Solution solve() override;

private:

    /**
     * @brief Führt  K-Means-Clustering auf der gegebenen Instanz durch
     * @return std::vector<Instance::Cluster> Ergebniscluster als Listen von Knoten-IDs.
     */
    std::vector<Instance::Cluster> KmeansClustering();
};

} // namespace ko::vrp
