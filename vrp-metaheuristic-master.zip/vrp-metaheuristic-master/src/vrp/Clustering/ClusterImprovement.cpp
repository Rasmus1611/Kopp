
#include "ClusterImprovement.h"
#include "ClusterSolver.h"
#include "vrp/TSP/TSPSolverDP.h"
#include "vrp/TSP/TSPSolverHeuristic.h"
#include <random>
#include <algorithm>

namespace ko::vrp {
Instance::TravelCost ClusterImprovement::runImprovement(Solution& solution, size_t maxClusterSize) {

    Instance::TravelCost maxImprovement = 0;
    Solution bestSolution = solution;

    for (size_t i = 0; i < maxClusterSize; ++i) {
        Solution solutionCopy(m_instance);
        solutionCopy.setRoutes(solution.getRoutes());

        const Instance::TravelCost improvement = improveSolution(solutionCopy, maxClusterSize);
        if (improvement > maxImprovement) {
            maxImprovement = improvement;
            bestSolution.setRoutes(solutionCopy.getRoutes());
        }
    }

    INFO("maxImprovement: " + std::to_string(maxImprovement));
    solution = bestSolution;
    return maxImprovement;
}

Instance::TravelCost ClusterImprovement::improveSolution(Solution& solution, size_t maxClusterSize) {

    // Iterationsstopp lässt sich variieren ab einer Instanzgröße von 15 verwenden wir einen Heuristischen solver um die
    // zwischenergebnisse zu berechnen
    int iterationsstopp;
    if (maxClusterSize < 15) {
        iterationsstopp = int(30000 / (maxClusterSize * maxClusterSize));
    }
    if (maxClusterSize >= 15) {
        iterationsstopp = int(100000 / (maxClusterSize * maxClusterSize));
    }

    int nichtsPassiertCounter = 0;

    Instance::TravelCost sumImprovements = 0;

    for (int i = 0; i < iterationsstopp; ++i) {
        // nachdem 50 mal nichts geändert wurde berechnen wir ab
        if (nichtsPassiertCounter == 50) {
            break;
        }

        std::random_device rd;  // Zufalls-Seed von der Hardware
        std::mt19937 gen(rd()); // Mersenne-Twister Zufallszahlengenerator
        std::uniform_int_distribution<Instance::NodeId> dist(0, m_instance.getNumberNodes() - 1);

        // zufälligen Node auswählen
        Instance::NodeId randomNode = dist(gen);

        // wenn der zufällige Node das Depot ist, gehe weiter
        if (randomNode == m_instance.getDepotNodeId())
            continue;

        Solution::Route* randomNodeRoute = nullptr;

        // node aus einem anderen Cluster mit geringster Distanz zu randomNode
        Instance::NodeId closestNode;
        Solution::Route* closestNodeRoute = nullptr;

        Instance::TravelCost minimumDistance = std::numeric_limits<Instance::TravelCost>::max();

        for (Solution::Route& route : solution.getRoutes()) {
            Instance::Cluster& cluster = route.cluster;

            // wenn randomNode im Cluster enthalten ist, überspringe dieses cluster
            if (std::find(cluster.begin(), cluster.end(), randomNode) != cluster.end()) {
                randomNodeRoute = &route;
                continue;
            }

            for (const Instance::NodeId& nodeId : cluster) {
                const Instance::TravelCost distanceToRandomNode = m_instance.getTravelCost(nodeId, randomNode);

                // finde node, der die kürzeste Distanz zu randomNode hat
                if (distanceToRandomNode < minimumDistance) {
                    minimumDistance = distanceToRandomNode;

                    closestNode = nodeId;
                    closestNodeRoute = &route;
                }
            }
        }

        // dürfte nicht eintreten, zu Debug-Zwecken hier trotzdem eine Überprüfung
        if (!randomNodeRoute || !closestNodeRoute) {
            ERROR("nullpointer!");
            continue;
        }

        // Checken, ob ein Übertrag von einer Node ins andere Cluster möglich ist oder ggf ein Swap
        Instance::Demand randomNodeDemand = m_instance.getNode(randomNode).m_demand;
        Instance::Demand closestNodeDemand = m_instance.getNode(closestNode).m_demand;
        Instance::Demand vehicleCapacity = m_instance.getVehicleCapacity();

        // bools sagen aus, ob der Tausch überhaupt möglich ist
        bool randomNodeToClosestRoute = (closestNodeRoute->totalDemand + randomNodeDemand <= vehicleCapacity);
        bool closestNodeToRandomRoute = (randomNodeRoute->totalDemand + closestNodeDemand <= vehicleCapacity);
        bool swapOfNodes = (randomNodeRoute->totalDemand - randomNodeDemand + closestNodeDemand <= vehicleCapacity) &&
                           (closestNodeRoute->totalDemand - closestNodeDemand + randomNodeDemand <= vehicleCapacity);

        // kein Tausch möglich
        if (!randomNodeToClosestRoute && !closestNodeToRandomRoute && !swapOfNodes) {
            continue;
        }

        // TSP für die vorherigen Cluster lösen
        const Instance::TravelCost costRandomNodeCluster =
          m_tspSolver->solve(randomNodeRoute->cluster).travelCost;
        const Instance::TravelCost costClosestNodeCluster =
          m_tspSolver->solve(closestNodeRoute->cluster).travelCost;

        const Instance::TravelCost initialCostSum = costClosestNodeCluster + costRandomNodeCluster;

        Instance::TravelCost ersparnisseRandomNodeToClosestRoute = std::numeric_limits<Instance::TravelCost>::min();
        Instance::TravelCost ersparnisseClosestNodeToRandomRoute = std::numeric_limits<Instance::TravelCost>::min();
        Instance::TravelCost ersparnisseSwap = std::numeric_limits<Instance::TravelCost>::min();

        // wenn Tausch möglich, berechne Ersparnisse von dem Tausch
        if (randomNodeToClosestRoute) {
            const Instance::TravelCost newCostSum =
              calcTotalCostWithNodeMove(randomNode, randomNodeRoute->cluster, closestNodeRoute->cluster);
            ersparnisseRandomNodeToClosestRoute = initialCostSum - newCostSum;
        }
        if (closestNodeToRandomRoute) {
            const Instance::TravelCost newCostSum =
              calcTotalCostWithNodeMove(closestNode, closestNodeRoute->cluster, randomNodeRoute->cluster);
            ersparnisseClosestNodeToRandomRoute = initialCostSum - newCostSum;
        }
        if (swapOfNodes) {
            const Instance::TravelCost newCostSum =
              calcTotalCostWithNodeSwap(randomNode, randomNodeRoute->cluster, closestNode, closestNodeRoute->cluster);
            ersparnisseSwap = initialCostSum - newCostSum;
        }

        // berechne maximal mögliches Ersparnis
        Instance::TravelCost maxImprovement =
          std::max({ ersparnisseSwap, ersparnisseRandomNodeToClosestRoute, ersparnisseClosestNodeToRandomRoute });

        // keine Verbesserung möglich
        if (maxImprovement <= 0) {
            nichtsPassiertCounter++;
            continue;
        }

        nichtsPassiertCounter = 0;
        sumImprovements += maxImprovement;

        // Cluster ändern, um bestes Ersparnis zu erzielen
        if (maxImprovement == ersparnisseSwap) {
            moveNodeToCluster(randomNode, randomNodeRoute->cluster, closestNodeRoute->cluster);
            moveNodeToCluster(closestNode, closestNodeRoute->cluster, randomNodeRoute->cluster);
        }
        else if (maxImprovement == ersparnisseRandomNodeToClosestRoute) {
            moveNodeToCluster(randomNode, randomNodeRoute->cluster, closestNodeRoute->cluster);
        }
        else if (maxImprovement == ersparnisseClosestNodeToRandomRoute) {
            moveNodeToCluster(closestNode, closestNodeRoute->cluster, randomNodeRoute->cluster);
        }

        randomNodeRoute->totalDemand = ClusterSolver::computeClusterDemand(m_instance, randomNodeRoute->cluster);
        closestNodeRoute->totalDemand = ClusterSolver::computeClusterDemand(m_instance, closestNodeRoute->cluster);
    }

    return sumImprovements;
}
void ClusterImprovement::moveNodeToCluster(const Instance::NodeId& nodeId,
  Instance::Cluster& fromCluster,
  Instance::Cluster& toCluster) {

    auto nodeIterator = std::find(fromCluster.begin(), fromCluster.end(), nodeId);
    if (nodeIterator == fromCluster.end()) {
        ERROR("Error moving node " + std::to_string(nodeId) + ": Node is not in given origin-Cluster!");
        return;
    }

    fromCluster.erase(std::find(fromCluster.begin(), fromCluster.end(), nodeId));
    toCluster.push_back(nodeId);
}

ClusterImprovement::ClusterImprovement(const Instance& instance)
  : Logger("ClusterImprovement")
  , m_instance(instance) {
    const size_t averageClusterSize = instance.getNumberNodes() / instance.getNumberVehicles();
    if (averageClusterSize >= 15) {
        m_tspSolver = std::make_unique<TSPSolverHeuristic>(m_instance);

    }
    else {
        m_tspSolver = std::make_unique<TSPSolverDP>(m_instance);
    }
}

Instance::TravelCost ClusterImprovement::calcTotalCostWithNodeMove(const Instance::NodeId& nodeId,
  Instance::Cluster& fromCluster,
  Instance::Cluster& toCluster) {

    Instance::Cluster newFromCluster = fromCluster;
    Instance::Cluster newToCluster = toCluster;

    moveNodeToCluster(nodeId, newFromCluster, newToCluster);
    const Instance::TravelCost costNewFromCluster = m_tspSolver->solve(newFromCluster).travelCost;
    const Instance::TravelCost costNewToCluster = m_tspSolver->solve(newToCluster).travelCost;

    return costNewFromCluster + costNewToCluster;
}

Instance::TravelCost ClusterImprovement::calcTotalCostWithNodeSwap(const Instance::NodeId& nodeIdA,
  Instance::Cluster& clusterA,
  const Instance::NodeId& nodeIdB,
  Instance::Cluster& clusterB) {

    Instance::Cluster newClusterA = clusterA;
    Instance::Cluster newClusterB = clusterB;

    moveNodeToCluster(nodeIdA, newClusterA, newClusterB);
    moveNodeToCluster(nodeIdB, newClusterB, newClusterA);

    const Instance::TravelCost costNewClusterA = m_tspSolver->solve(newClusterA).travelCost;
    const Instance::TravelCost costNewClusterB = m_tspSolver->solve(newClusterB).travelCost;

    return costNewClusterA + costNewClusterB;
}


} // namespace ko::vrp