#include "BinPackingClusterSolver.h"
#include <algorithm>
namespace ko::vrp {

bool BinPackingClusterSolver::depthFirstSearch(
  std::vector<Instance::NodeId>::const_iterator currentNodeIter,
  std::map<Instance::VehicleId, Instance::Demand>& vehicleLoads,
  std::map<Instance::NodeId, Instance::VehicleId>& vehicleAssignments
) {

    // Basisfall: Alle Knoten wurden zugewiesen
    if (currentNodeIter == m_allNodeIds.end())
        return true;

    const Instance::NodeId currentNodeId = *currentNodeIter;
    const Instance::Demand currentNodeDemand = m_instance.getNode(currentNodeId).m_demand;

    // Versuche, den aktuellen Knoten jedem Fahrzeug zuzuweisen
    for (Instance::VehicleId vehicle = 0; vehicle < m_instance.getNumberVehicles(); ++vehicle) {
        if (vehicleLoads[vehicle] + currentNodeDemand > m_instance.getVehicleCapacity())
            continue;

        // Addiere currentNodeDemand zu vehicle
        vehicleLoads[vehicle] = vehicleLoads[vehicle] + currentNodeDemand;
        vehicleAssignments[currentNodeId] = vehicle;

        // Rekursiver Aufruf, wobei currentNodeIter zu vehicle zugewiesen werden konnte
        if (depthFirstSearch( ++currentNodeIter, vehicleLoads, vehicleAssignments))
            return true;

        // Backtracking: Zuweisung zurücknehmen
        vehicleLoads[vehicle] = vehicleLoads[vehicle] - currentNodeDemand;
        vehicleAssignments.erase(currentNodeId);
    }
    return false;
}

Solution BinPackingClusterSolver::solve() {
    Solution solution(m_instance);

    std::map<Instance::VehicleId, Instance::Demand> vehicleLoads;
    std::map<Instance::NodeId, Instance::VehicleId> vehicleAssignments;

    bool solvable = depthFirstSearch(m_allNodeIds.cbegin(), vehicleLoads, vehicleAssignments);
    if (!solvable) {
        ERROR("Fehler: Es konnte keine exakte Zuweisung aller Knoten gefunden werden.");
        return solution;
    }

    // Erstelle Fahrzeug-Cluster anhand der DepthFirstSearch-Zuweisung
    std::vector<Instance::Cluster> vehicleClusters(m_instance.getNumberVehicles());
    for (const auto& [key, value] : vehicleAssignments) {
        vehicleClusters[value].push_back(key);
    }

    // Füge alle Cluster zur Solution hinzu
    for (const Instance::Cluster& cluster : vehicleClusters) {
        solution.addCluster(cluster);
    }

    return solution;
}
} // namespace ko::vrp