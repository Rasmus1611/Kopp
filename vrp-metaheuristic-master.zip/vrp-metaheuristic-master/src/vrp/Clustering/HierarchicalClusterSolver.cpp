#include "HierarchicalClusterSolver.hpp"
#include <algorithm>
#include <iostream>

namespace ko::vrp {


std::vector<Instance::Cluster> HierarchicalClusterSolver::hierarchicalClustering() {
    std::vector<Instance::Cluster> clusters;

    // Initial: Jeder Knoten (außer dem Depot) bildet einen eigenes Cluster.
    for (const auto& node : m_instance.getAllNodes()) {
        if (node.m_nodeId == m_instance.getDepotNodeId())
            continue;
        clusters.push_back({node.m_nodeId});
    }

    //Solange es merging ausgeführt werden kann
    bool merged = true;
    while (merged) {
        merged = false;
        Instance::TravelCost bestDistance = std::numeric_limits<Instance::TravelCost>::max();
        int mergeIndex1 = -1, mergeIndex2 = -1;

        // Suche nach zwei Clustern, die zusammengeführt werden können (unter Einhaltung der Kapazitätsgrenze)
        for (size_t i = 0; i < clusters.size(); ++i) {
            for (size_t j = i + 1; j < clusters.size(); ++j) {
                Instance::Demand totalDemand = computeClusterDemand(m_instance, clusters[i]) +
                                               computeClusterDemand(m_instance, clusters[j]);

                if (totalDemand <= m_instance.getVehicleCapacity()) {
                    Instance::TravelCost distance = computeClusterDistance(m_instance, clusters[i], clusters[j]);
                    if (distance < bestDistance) {
                        bestDistance = distance;
                        mergeIndex1 = i;
                        mergeIndex2 = j;
                    }
                }
            }
        }

        //Nach erfolgreichen mergen sorge für eine weitere Schleife
        if (mergeIndex1 != -1 && mergeIndex2 != -1) {
            clusters[mergeIndex1].insert(clusters[mergeIndex1].end(),
              clusters[mergeIndex2].begin(),
              clusters[mergeIndex2].end());
            clusters.erase(clusters.begin() + mergeIndex2);
            merged = true;
        }
    }

    return clusters;
}


Solution HierarchicalClusterSolver::solve() {
    Solution solution(m_instance);
    auto clusters = hierarchicalClustering();

    for (const auto& cluster : clusters) {
        solution.addCluster(cluster);
    }

    return solution;
}

} // namespace ko::vrp