/**
 * @file HierarchicalClusterSolver.hpp
 * @brief Implementierung des hierarchischen Clustering für das VRP
 *
 * Basierend auf dem Paper "Algorithms for Hierarchical Clustering: An Overview, II" von Fionn Murtagh und Pedro Contreras
 *
 * @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
 * @date 2025-01-29
 */

#pragma once

#include "ClusterSolver.h"
#include "vrp/Instance.hpp"
#include "vrp/Solution.h"
#include <cmath>
#include <limits>
#include <memory>
#include <vector>

namespace ko::vrp {

/**
 * @class HierarchicalClusterSolver
 * @brief Implementierung des hierarchischen Clustering für das VRP.
 */
class HierarchicalClusterSolver : public ClusterSolver {
public:
    explicit HierarchicalClusterSolver(const Instance& instance)
      : ClusterSolver(instance, "Hierarchical ClusterSolver") {};

    /**
     * @brief Löst das VRP, indem die Knoten mittels hierarchischem Clustering gruppiert werden
     * @return Solution Die berechnete Clusterlösung
     */
    Solution solve() override;

private:
    /**
     * @brief Führt den hierarchischen Clustering Algorithmus aus, um Cluster zu bilden.
     * @return Ein Vektor mit den berechneten Clustern.
     */
    std::vector<Instance::Cluster> hierarchicalClustering();
};

} // namespace ko::vrp