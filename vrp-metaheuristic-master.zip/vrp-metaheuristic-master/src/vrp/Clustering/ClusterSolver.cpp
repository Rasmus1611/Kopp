#include "ClusterSolver.h"

namespace ko::vrp {

// Berechnet die Gesamtnachfrage eines Clusters durch Aufsummieren der Nachfragen seiner Knoten.
Instance::Demand ClusterSolver::computeClusterDemand(const Instance& instance, const Instance::Cluster& cluster) {
    Instance::Demand totalDemand = 0;

    // Nachfrage aller Knoten summieren
    for (const auto& nodeId : cluster) {
        totalDemand += instance.getNode(nodeId).m_demand;
    }

    return totalDemand;
}

// Berechnet die minimale Entfernung zwischen zwei Clustern (kürzeste Distanz zwischen beliebigen Knotenpaaren).
Instance::TravelCost ClusterSolver::computeClusterDistance(const Instance& instance,
  const Instance::Cluster& cluster1,
  const Instance::Cluster& cluster2) {

    Instance::TravelCost minDistance = std::numeric_limits<Instance::TravelCost>::max();

    // Jedes Knotenpaar prüfen und minimale Distanz ermitteln
    for (const auto& nodeId1 : cluster1) {
        for (const auto& nodeId2 : cluster2) {
            Instance::TravelCost distance = instance.getTravelCost(nodeId1, nodeId2);
            if (distance < minDistance) {
                minDistance = distance;
            }
        }
    }

    return minDistance;
}

} // namespace ko::vrp
