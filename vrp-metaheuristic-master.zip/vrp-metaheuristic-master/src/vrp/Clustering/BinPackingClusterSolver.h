/**
* @file BinPackingClusterSolver.h
* @brief Klasse für das Lösen des BinPackingProblems auf Clustern
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-12
 */


#pragma once
#include "ClusterSolver.h"
#include <map>
namespace ko::vrp {

class BinPackingClusterSolver : public ClusterSolver {

private:
    /// Speichert alle NodeIds der Instanz
    const std::vector<Instance::NodeId> m_allNodeIds;

    /** Führt die Tiefensuche für das BinPacking-Problem für die Nodes in m_allNodeIds durch.
     *
     * @param currentNodeIter Iterator des aktuellen Nodes in m_allNodeIds
     * @param vehicleLoads Map, welche die aktuelle Beladung der Fahrzeuge speichert. Hier wird auch das Endergebnis gespeichert.
     * @param vehicleAssignments Map, welche für jeden Node speichert, von welchem Fahrzeug er beliefert wird. Hier wird auch das Endergebnis gespeichert.
     * @return true wenn BinPacking lösbar ist, false sonst
     */
    bool depthFirstSearch(
      std::vector<Instance::NodeId>::const_iterator currentNodeIter,
      std::map<Instance::VehicleId, Instance::Demand>& vehicleLoads,
      std::map<Instance::NodeId, Instance::VehicleId>& vehicleAssignments
        );

public:
    /// Konstruktor
    explicit BinPackingClusterSolver(const Instance& instance)
      : ClusterSolver(instance, "BinPacking ClusterSolver")
      , m_allNodeIds(instance.getNodeIdsWithoutDepot()) {};

    /** Löst die Instanz per Tiefensuche als BinPacking-Problem.
     *
     * @return Lösung mit Routen wenn BinPacking lösbar ist, leere Lösung sonst
     */
    Solution solve() override;
};

} // namespace ko::vrp
