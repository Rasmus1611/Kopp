#include "KMeansClusterSolver.hpp"
#include <algorithm>
#include <random>
#include <limits>
#include <cmath>

namespace ko::vrp {

std::vector<Instance::Cluster> KmeansClusterSolver::KmeansClustering() {
    // Anzahl der Cluster entspricht der Anzahl der Fahrzeuge.
    int k = static_cast<int>(m_instance.getNumberVehicles());

    // Alle Knoten (außer Depot) sammeln.
    std::vector<const Instance::Node*> nodes;
    for (const auto& node : m_instance.getAllNodes()) {
        if (node.m_nodeId == m_instance.getDepotNodeId())
            continue;
        nodes.push_back(&node);
    }
    if (nodes.empty() || k <= 0)
        return {}; // keine Knoten zum Clustern

    // Falls k größer als die Anzahl der Knoten ist, anpassen.
    if (k > static_cast<int>(nodes.size()))
        k = static_cast<int>(nodes.size());

    // Initialisierung der Zentroide durch Zufall
    using Centroid = std::pair<double, double>;
    std::vector<Centroid> centroids;
    {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, nodes.size() - 1);
        std::vector<bool> chosen(nodes.size(), false);
        while (centroids.size() < static_cast<size_t>(k)) {
            int index = dis(gen);
            if (!chosen[index]) {
                chosen[index] = true;
                centroids.push_back({
                  static_cast<double>(nodes[index]->m_x),
                  static_cast<double>(nodes[index]->m_y)
                });
            }
        }
    }

    // Vektor für Clusterzuweisungen und Cluster-Demands.
    std::vector<std::vector<const Instance::Node*>> clusters(k);
    const auto vehicleCapacity = m_instance.getVehicleCapacity();
    std::vector<Instance::Demand> clusterDemands(k, 0);

    // Parameter für die Gewichtung der Kapazitätskomponente.
    const double gamma = 1.0; // Variable für Maschine learning

    int iterations = 0;
    bool changed = true;
    const int maxIterations = 100;
    const double tolerance = 1e-4;

    while (changed && iterations < maxIterations) {
        // Cluster zurücksetzen.
        for (auto& cluster : clusters)
            cluster.clear();
        std::fill(clusterDemands.begin(), clusterDemands.end(), 0);

        //Knoten absteigend nach Demand sortieren.
        auto sortedNodes = nodes;
        std::sort(sortedNodes.begin(), sortedNodes.end(), [](const Instance::Node* a, const Instance::Node* b) {
            return a->m_demand > b->m_demand;
        });

        // Zuweisung: Jeder Knoten wird dem Cluster zugeordnet, das den minimalen gewichteten Score liefert.
        for (const auto* node : sortedNodes) {
            double bestScore = std::numeric_limits<double>::max();
            int bestCluster = -1;
            double nodeX = static_cast<double>(node->m_x);
            double nodeY = static_cast<double>(node->m_y);
            for (int i = 0; i < k; i++) {
                if (clusterDemands[i] + node->m_demand <= vehicleCapacity) {
                    double dx = nodeX - centroids[i].first;
                    double dy = nodeY - centroids[i].second;
                    double d = std::hypot(dx, dy);
                    double loadFraction = static_cast<double>(clusterDemands[i]) / vehicleCapacity;
                    double score = d * (1 + gamma * loadFraction);
                    if (score < bestScore) {
                        bestScore = score;
                        bestCluster = i;
                    }
                }
            }
            // Fallback: Falls kein Cluster die Kapazitätsbedingung erfüllt, wird der nächstgelegene Cluster gewählt.
            if (bestCluster == -1) {
                for (int i = 0; i < k; i++) {
                    double dx = nodeX - centroids[i].first;
                    double dy = nodeY - centroids[i].second;
                    double d = std::hypot(dx, dy);
                    if (d < bestScore) {
                        bestScore = d;
                        bestCluster = i;
                    }
                }
            }
            clusters[bestCluster].push_back(node);
            clusterDemands[bestCluster] += node->m_demand;
        }

        // Aktualisiere die Zentroide basierend auf den zugewiesenen Knoten.
        changed = false;
        for (int i = 0; i < k; i++) {
            if (clusters[i].empty())
                continue; // Leere Cluster überspringen.
            double sumX = 0.0, sumY = 0.0;
            for (const auto* node : clusters[i]) {
                sumX += node->m_x;
                sumY += node->m_y;
            }
            Centroid newCentroid { sumX / clusters[i].size(), sumY / clusters[i].size() };
            double dx = newCentroid.first - centroids[i].first;
            double dy = newCentroid.second - centroids[i].second;
            if (std::hypot(dx, dy) > tolerance)
                changed = true;
            centroids[i] = newCentroid;
        }
        iterations++;
    }

    // Umwandlung der Cluster in das erwartete Format (Liste von NodeIds).
    std::vector<Instance::Cluster> result;
    for (const auto& cluster : clusters) {
        Instance::Cluster clusterIds;
        for (const auto* node : cluster)
            clusterIds.push_back(node->m_nodeId);
        result.push_back(clusterIds);
    }
    return result;
}


Solution KmeansClusterSolver::solve() {
    Solution solution(m_instance);
    for (const auto& cluster : KmeansClustering()) {
        solution.addCluster(cluster);
    }
    return solution;
}

} // namespace ko::vrp
