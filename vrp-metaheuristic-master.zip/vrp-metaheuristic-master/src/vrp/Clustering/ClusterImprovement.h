/**
* @file ClusterImprovement.h
* @brief Klasse für Verbesserung von Clustern
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-12
*/

#pragma once

#include "vrp/Solution.h"
#include "vrp/TSP/TSPSolver.h"
namespace ko::vrp {

class ClusterImprovement : public Logger {
private:
    std::unique_ptr<TSPSolver> m_tspSolver;
    const Instance& m_instance;

    /** Moves node from the given fromCluster into the toCluster.
     *
     * @param nodeId node to move
     * @param fromCluster cluster that contains the node
     * @param toCluster cluster the node should be moved to
     */
    void moveNodeToCluster(const Instance::NodeId& nodeId, Instance::Cluster& fromCluster, Instance::Cluster& toCluster);

    /** Moves the node in fromCluster to toCluster and calculates the total TravelCost of both clusters. Reverts the changes afterwards.
     *
     * @param nodeId node to move
     * @param fromCluster cluster that contains the node
     * @param toCluster cluster the node should be moved to
     * @return the total TravelCost of both clusters, when node is in toCluster instead of fromCluster
     */
    Instance::TravelCost calcTotalCostWithNodeMove(const Instance::NodeId& nodeId, Instance::Cluster& fromCluster, Instance::Cluster& toCluster);

    Instance::TravelCost calcTotalCostWithNodeSwap(const Instance::NodeId& nodeIdA, Instance::Cluster& clusterA, const Instance::NodeId& nodeIdB, Instance::Cluster& clusterB);

    /** Verbessert die gegebene Cluster
     * Eine Node wird zufällt ausgewählt und die nächste Node in einem anderen Cluster gesucht
     * Wenn der Tausch oder Übertrag einer Node in das jeweils andere Cluster eine Ersparnis bringt, dann wird diese Änderung an den Clustern durchgefährt
     *
     * @param solution enthält zulässige Cluster
     * @param maxClusterSize wird genutzt um die Zeit durch Anzahl von Iterationen und die Nutzen des exakten oder heuristischen TSP solver zu begrenzen
     * @param instance Instance in der die Nodes enthalten sind
     */
    Instance::TravelCost improveSolution(Solution& solution, size_t maxClusterSize);
public:
    explicit ClusterImprovement(const Instance& instance);

    /** Führt die improveSolution-Methode mehrmals aus und setzt die Lösung mit maximalenm Improvement als solution
     *
     * @param solution enthält zulässige Cluster
     * @param maxClusterSize wird genutzt um die Zeit durch Anzahl von Iterationen und die Nutzen des exakten oder heuristischen TSP solver zu begrenzen
     * @return Wert, um den die Lösung verbessert wurde
     */
    Instance::TravelCost runImprovement(Solution& solution, size_t maxClusterSize);
};

} // namespace ko::vrp
