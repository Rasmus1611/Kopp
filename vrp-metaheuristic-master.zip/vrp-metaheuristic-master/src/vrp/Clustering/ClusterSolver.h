/**
* @file ClusterSolver.h
* @brief Abstrakte Klasse für grundlegende Funktionen beim Clustering
 *
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-12
*/


#pragma once

#include "vrp/Solution.h"
namespace ko::vrp {

class ClusterSolver : public Logger {
protected:
    const Instance& m_instance;

public:
    explicit ClusterSolver(const Instance& instance)
      : ClusterSolver(instance, "ClusterSolver") {};

    explicit ClusterSolver(const Instance& instance, const std::string& loggerName)
      : Logger(loggerName), m_instance(instance) {};

    virtual Solution solve() = 0;

    /** Berechnet die Summe der Demands aller Nodes im Clusters.
     *
     * @param instance Instanz, welche die Nodes des Clusters enthält
     * @param cluster Cluster, dessen Gesamt-Demand berechnet werden soll
     * @return Summe der Demands
     */
    static Instance::Demand computeClusterDemand(const Instance& instance, const Instance::Cluster& cluster);

    /** Berechnet die minimale Distanz zwischen zwei Knoten, wobei ein Knoten aus cluster1 und der andere aus cluster2 stammt.
     *
     * @param instance Instanz, welche die Knoten der beiden Cluster enthält.
     * @param cluster1
     * @param cluster2
     * @return minimale Distanz zwischen den beiden Clustern
     */
    static Instance::TravelCost computeClusterDistance(const Instance& instance, const Instance::Cluster& cluster1, const Instance::Cluster& cluster2);
};

}

