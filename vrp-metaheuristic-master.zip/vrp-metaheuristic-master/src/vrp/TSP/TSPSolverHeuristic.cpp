#include "TSPSolverHeuristic.h"
#include <algorithm>
#include <limits>
#include <vector>

namespace ko::vrp {

Solution::Route TSPSolverHeuristic::solve(Instance::Cluster& cluster) {
    Solution::Route route;

    // Wenn Cluster leer: keine Reisekosten
    if (cluster.empty()) {
        route.travelCost = 0.0;
        return route;
    }

    // Basisroute mit Nearest Neighbor
    Instance::Cluster clusterRoute = nearestNeighbor(cluster);

    // Verbesserung der Route durch das 2-opt Verbesserungsverfahren
    twoOpt(clusterRoute);

    // Gesamtkosten der optimierten Route berechnen
    Instance::TravelCost totalCost = computeTotalCost(clusterRoute);

    // Ergebnisroute fertig machen
    route.cluster = clusterRoute;
    route.travelCost = totalCost;

    return route;
}


Instance::Cluster TSPSolverHeuristic::nearestNeighbor(const Instance::Cluster& cluster) {
    const Instance::NodeId depot = m_instance.getDepotNodeId();

    // Starte mit dem Knoten, der am nächsten zum Depot liegt
    Instance::NodeId startNode = cluster.front();
    Instance::TravelCost minDistance = std::numeric_limits<Instance::TravelCost>::infinity();
    for (const Instance::NodeId& nodeId : cluster) {
        Instance::TravelCost distance = m_instance.getTravelCost(depot, nodeId);
        if (distance < minDistance) {
            minDistance = distance;
            startNode = nodeId;
        }
    }

    // Route initialisieren
    Instance::Cluster route;
    route.reserve(cluster.size());
    route.push_back(startNode);

    // Noch zu besuchende Knoten sammeln
    Instance::Cluster unvisited;
    unvisited.reserve(cluster.size() - 1);
    for (const Instance::NodeId& nodeId : cluster) {
        if (nodeId != startNode) {
            unvisited.push_back(nodeId);
        }
    }

    // Nächsten Nachbarn hinzufügen, bis alle Knoten besucht wurden
    Instance::NodeId current = startNode;
    while (!unvisited.empty()) {
        Instance::TravelCost nearestDistance = std::numeric_limits<Instance::TravelCost>::infinity();
        size_t selectedIndex = 0;

        // Nächsten Knoten ermitteln
        for (size_t i = 0; i < unvisited.size(); ++i) {
            Instance::TravelCost distance = m_instance.getTravelCost(current, unvisited[i]);
            if (distance < nearestDistance) {
                nearestDistance = distance;
                selectedIndex = i;
            }
        }

        // Ausgewählten Knoten hinzufügen und aus unvisited entfernen
        Instance::NodeId selectedNode = unvisited[selectedIndex];
        route.push_back(selectedNode);
        current = selectedNode;
        unvisited.erase(unvisited.begin() + selectedIndex);
    }

    return route;
}


void TSPSolverHeuristic::twoOpt(Instance::Cluster& cluster) {
    bool improved = true;

    // Solange Verbesserungen gefunden werden
    while (improved) {
        improved = false;
        for (size_t i = 0; i < cluster.size() - 1; ++i) {
            for (size_t j = i + 1; j < cluster.size(); ++j) {
                double originalCost = computeTotalCost(cluster);
                // Teilroute zwischen i und j umdrehen
                std::reverse(cluster.begin() + i + 1, cluster.begin() + j + 1);
                double newCost = computeTotalCost(cluster);
                if (newCost < originalCost) {
                    improved = true; // Verbesserung übernommen
                } else {
                    // Keine Verbesserung, Umkehrung rückgängig machen
                    std::reverse(cluster.begin() + i + 1, cluster.begin() + j + 1);
                }
                if (improved) break;
            }
            if (improved) break;
        }
    }
}


Instance::TravelCost TSPSolverHeuristic::computeTotalCost(const Instance::Cluster& cluster) const {
    if (cluster.empty()) return 0.0;

    double totalCost = 0.0;
    const Instance::NodeId depot = m_instance.getDepotNodeId();

    // Kosten vom Depot zum ersten Knoten
    totalCost += m_instance.getTravelCost(depot, cluster.front());

    // Kosten zwischen Knoten der Route
    for (size_t i = 0; i < cluster.size() - 1; ++i) {
        totalCost += m_instance.getTravelCost(cluster[i], cluster[i + 1]);
    }

    // Kosten vom letzten Knoten zurück zum Depot
    totalCost += m_instance.getTravelCost(cluster.back(), depot);

    return totalCost;
}

} // namespace ko::vrp
