/**
* @file TSPSolverHeuristic.h
* @brief Implementierung einer Heuristik, die das TSP für das VRP via Nearest Neighbour und 2-opt löst
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-12
 */


#pragma once

#include "TSPSolver.h"
#include <vector>

namespace ko::vrp {

/**
 * @brief TSPSolverHeuristic nutzt Nearest Neighbor und 2-opt für eine schnelle und gute Lösung des TSP
 */
class TSPSolverHeuristic : public TSPSolver {
public:
    /**
     * @brief Konstruktor zur Initialisierung
     * @param instance Referenz auf die Problem-Instanz
     */
    TSPSolverHeuristic(const Instance& instance) : TSPSolver(instance) {}

    /**
     * @brief Destruktor.
     */
    ~TSPSolverHeuristic() override = default;

    /**
     * @brief Berechnet heuristisch eine Route für das gegebene Cluster.
     * @param cluster Referenz auf das Cluster
     * @return Solution::Route die berechnete Route mit Gesamtkosten
     */
    Solution::Route solve(Instance::Cluster& cluster) override;

private:
    /**
     * @brief Erstellt eine initiale Route mittels Nearest Neighbor
     * @param cluster konstante Referenz auf die Menge von Knoten, die besucht werden sollen
     * @return Instance::Cluster initiale Route
     */
    Instance::Cluster nearestNeighbor(const Instance::Cluster& cluster);

    /**
     * @brief Verbessert die übergebene Route durch 2-opt
     * @param cluster Referenz auf die zu optimierende Route
     */
    void twoOpt(Instance::Cluster& cluster);

    /**
     * @brief Berechnet die Gesamtkosten einer Route
     * @param cluster Konstante Referenz auf die Route dessen Gesamtkosten berechnet werden
     * @return Instance::TravelCost Gesamtkosten der Route
     */
    [[nodiscard]] Instance::TravelCost computeTotalCost(const Instance::Cluster& cluster) const;
};

} // namespace ko::vrp