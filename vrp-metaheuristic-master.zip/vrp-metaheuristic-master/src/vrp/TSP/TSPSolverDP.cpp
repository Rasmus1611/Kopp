#include "TSPSolverDP.h"
#include <iostream>
#include <map>

namespace ko::vrp {

std::string TSPSolverDP::toString(const NodeSubset& subset) {
    std::string result = "{";
    for (const Instance::NodeId& nodeId : subset) {
        result += std::to_string(nodeId);
        if (nodeId != *subset.end())
            result += ", ";
    }
    result += "}";
    return result;
}

std::string TSPSolverDP::toString(const TSPSolverKey& tspSolverKey) {
    return "Subset: " + toString(tspSolverKey.subset) + " | endNode " + std::to_string(tspSolverKey.endNode);
}


Solution::Route TSPSolverDP::solve(Instance::Cluster& cluster) {
//    INFO("TSP Solver für Cluster: " + Instance::toString(cluster));
//    INFO("Solving TSP of size " + std::to_string(cluster.size()) + "...");

    std::map<TSPSolverKey, Instance::TravelCost> costMap;
    const Instance::NodeId depotId = m_instance.getDepotNodeId();

    // Initialisierung für alle Knoten/Einelementigen Teilmengen: Distanz vom Knoten zum Deopt
    for (const Instance::NodeId& nodeId : cluster) {
        const Instance::TravelCost abstandDepot = m_instance.getTravelCost(depotId, nodeId);
        const NodeSubset subset{ nodeId };
        const TSPSolverKey key(subset, nodeId);

        costMap.insert({ key, abstandDepot });
    }

    // Berechnung in k Schichten (k = Anzahl Knoten ohne das Depot)
    for (std::size_t k = 2; k <= cluster.size() + 1; ++k) {
        // kSubsets wird gefüllt mit allen k-elementigen Teilmengen des Clusters
        std::vector<TSPSolverDP::NodeSubset> kSubsets = getSubsetsWithCardinality(cluster, k);

        // Berechnung über alle k-elementigen Teilmengen des Clusters
        for (const NodeSubset& currentSubset : kSubsets) {

            // Berechnung über jeden Knoten, der in der k-elementigen Teilmenge ist
            for (const Instance::NodeId& currentNode : currentSubset) {

                NodeSubset lookupSubset = currentSubset;
                lookupSubset.erase(currentNode);

                Instance::TravelCost minimumCost = std::numeric_limits<Instance::TravelCost>::max();

                // In einer Ebene darunter (k-1) wird über alle Subsets ohne currentNode iteriert
                for (const Instance::NodeId& layerBelowNode : lookupSubset) {
                    const TSPSolverKey lookupKey(lookupSubset, layerBelowNode);
                    const Instance::TravelCost costMapTravelCost = costMap[lookupKey];
                    const Instance::TravelCost costCurrentNodeToLayerBelowNode =
                      m_instance.getTravelCost(currentNode, layerBelowNode);

                    const Instance::TravelCost travelCostGesamt = costMapTravelCost + costCurrentNodeToLayerBelowNode;
                    if (travelCostGesamt < minimumCost) {
                        minimumCost = travelCostGesamt;
                    }
                }

                const TSPSolverKey newKey(currentSubset, currentNode);
                costMap.insert({ newKey, minimumCost });
            }
        }
    }

    // Berechnung der minimalen Kosten
    Instance::TravelCost globalMin = std::numeric_limits<Instance::TravelCost>::max();
    Instance::NodeId endNode = cluster.front();

    NodeSubset subsetAllNodes = getSubsetsWithCardinality(cluster, cluster.size())[0];

    for (const Instance::NodeId& nodeId : cluster) {
        const TSPSolverKey key(subsetAllNodes, nodeId);

        const Instance::TravelCost cost = costMap[key] + m_instance.getTravelCost(nodeId, depotId);
        if (cost < globalMin) {
            globalMin = cost;
            endNode = nodeId;
        }
    }
//    INFO("minimale Kosten: " + std::to_string(globalMin));

    // optimalen Weg suchen
    Instance::Cluster clusterResult{ endNode };
    findShortestPath(costMap, clusterResult, subsetAllNodes);

//    INFO("kürzester Weg: " + Instance::toString(clusterResult));

    return { clusterResult, globalMin };
}

std::vector<TSPSolverDP::NodeSubset> TSPSolverDP::getSubsetsWithCardinalityHelper(const Instance::Cluster& cluster,
  std::vector<size_t>& indices,
  size_t size,
  size_t index,
  size_t cardinality) {
    if (size == cardinality) {
        NodeSubset subset;
        for (size_t i = 0; i < cardinality; ++i) {
            subset.insert(cluster[indices[i]]);
        }

        std::vector<NodeSubset> subsetVector;
        subsetVector.emplace_back(subset);
        return subsetVector;
    }

    std::vector<NodeSubset> subsetVector;
    for (std::size_t i = index; i < cluster.size(); ++i) {

        indices.push_back(i);

        // neue vectorWithNewSubsets berechnen mit index i+1
        const std::vector<NodeSubset> vectorWithNewSubsets =
          getSubsetsWithCardinalityHelper(cluster, indices, size + 1, i + 1, cardinality);

        // vectorWithNewSubsets an subsetVector anhängen
        subsetVector.insert(subsetVector.end(), vectorWithNewSubsets.begin(), vectorWithNewSubsets.end());

        indices.pop_back();
    }

    return subsetVector;
}

std::vector<TSPSolverDP::NodeSubset> TSPSolverDP::getSubsetsWithCardinality(const Instance::Cluster& cluster,
  size_t cardinality) {
    if (cardinality > cluster.size())
        return {};

    std::vector<size_t> indices;
    return getSubsetsWithCardinalityHelper(cluster, indices, 0, 0, cardinality);
}

void TSPSolverDP::findShortestPath(const std::map<TSPSolverKey, Instance::TravelCost>& costMap,
  Instance::Cluster& result,
  NodeSubset& remainingNodes) {

    // Abbruchkriterium, wenn nur noch ein Knoten nicht gewählt wurde
    if (remainingNodes.size() == 1) {
        return;
    }

    // Backtracking in tieferer ebene ohne lastNode
    Instance::NodeId lastNode = result.back();
    remainingNodes.erase(lastNode);

    // Suche des besten Vorgängers (minNode) für lastNode
    Instance::TravelCost minCost = std::numeric_limits<Instance::TravelCost>::max();
    Instance::NodeId minNode;
    for (const Instance::NodeId nodeId : remainingNodes) {
        TSPSolverKey key(remainingNodes, nodeId);

        Instance::TravelCost travelCost = costMap.at(key) + m_instance.getTravelCost(nodeId, lastNode);
        if (travelCost < minCost) {
            minCost = travelCost;
            minNode = key.endNode;
        }
    }
    //Speichern des Vorgängers und dann neues Aufrufen der Methode zur Suche des Vorgänger-Vorgängers
    result.push_back(minNode);
    findShortestPath(costMap, result, remainingNodes);
}

} // namespace ko::vrp