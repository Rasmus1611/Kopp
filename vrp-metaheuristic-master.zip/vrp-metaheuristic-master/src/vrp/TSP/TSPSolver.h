/**
* @file TSPSolver.h
* @brief Abstrakte Klasse für das TSP
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-12
*/

#pragma once

#include "util/Logger.hpp"
#include "vrp/Instance.hpp"
#include "vrp/Solution.h"

namespace ko::vrp {

/**
* @brief Abstrakte Klasse für verschiedene TSP Implementierungen
*/
class TSPSolver : public Logger {

protected:
   /**
    * @brief Referenz zur aktuellen VRP/TSP-Problem-Instanz
    */
   const Instance& m_instance;

public:
   /**
    * @brief Konstruktor zur Initialisierung der Problem-Instanz
    * @param instance Referenz auf die Instanz des zu lösenden Problems
    */
   explicit TSPSolver(const Instance& instance)
     : Logger("TSPSolver"), m_instance(instance) {};

   /** @brief
    * Standard-Destruktor.
    */
   ~TSPSolver() override = default;

   /**
    * @brief Löst das TSP für einen gegebenen Cluster und gibt eine Route zurück
    * @param cluster Referenz auf den Cluster von Knoten, der als TSP gelöst werden soll.
    * @return Solution::Route Die optimale oder heuristisch gefundene Route.
    */
   virtual Solution::Route solve(Instance::Cluster& cluster) = 0;
};

} // namespace ko::vrp
