/**
* @file TSPSolverDP.h
* @brief Implementierung eines Solvers, der das TSP exakt für das VRP via dynamische Programierung löst
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-12
 */

#pragma once

#include "util/Logger.hpp"
#include "vrp/Instance.hpp"
#include "vrp/Solution.h"
#include "TSPSolver.h"
#include <map>
#include <set>
#include <string>
#include <vector>

namespace ko::vrp {

class TSPSolverDP : public TSPSolver {
private:
    using NodeSubset = std::set<Instance::NodeId>;

    /**
     * Key, der für die Speicherstruktur Map genutzt wird, um Zwischenergebnisse zu speichern und einfach aufzurufen
     */
    struct TSPSolverKey {
        NodeSubset subset;
        Instance::NodeId endNode;

        TSPSolverKey(NodeSubset subset, Instance::NodeId endNode)
          : subset(std::move(subset))
          , endNode(endNode) {};

        bool operator<(const TSPSolverKey& other) const {
            if (subset != other.subset)
                return subset < other.subset;

            return endNode < other.endNode;
        }
    };

    /** Gibt alle Subsets des Clusters mit gewünschter Kardinalität zurück.
     * Wird rekursiv aufgerufen.
     *
     * @param cluster
     * @param indices dynamischer Vektor welcher die Indizes der Nodes aus dem Cluster enthält, welche für das aktuell
     * berechnete Subset benötigt werden
     * @param size Größe des aktuell berechneten Subsets
     * @param index nur Indizes > index werden in das Subset aufgenommen
     * @param cardinality gewünschte Kardinalität der Subsets
     * @return Vektor von Subsets mit Kardinalität k
     */
    std::vector<NodeSubset> getSubsetsWithCardinalityHelper(const Instance::Cluster& cluster,
      std::vector<size_t>& indices,
      size_t size,
      size_t index,
      size_t cardinality);

    /** Gibt alle Subsets des Clusters mit gewünschter Kardinalität zurück
     *
     * @param cluster Cluster in dem die Subsets gesucht werden
     * @param cardinality Kardinalität der Teilmengen, die zurückgegeben werden sollen
     * @return Vektor von Subsets mit Kardinalität k
     */
    std::vector<NodeSubset> getSubsetsWithCardinality(const Instance::Cluster& cluster, size_t cardinality);

    /** Findet den kürzesten Weg und speichert ihn in dem result-Vektor.
     *
     * @param costMap gefüllte Kosten-Map
     * @param result Vektor, in dem das Ergebnis gespeichert wird
     * @param remainingNodes Subset der verbleibenden Nodes (für rekursiven Aufruf, soll initial alle Nodes enthalten)
     */
    void findShortestPath(const std::map<TSPSolverKey, Instance::TravelCost>& costMap,
      Instance::Cluster& result,
      NodeSubset& remainingNodes);

    /** Gibt ein Subset als string-Repräsentation zurück
     *
     * @param subset Subset, welches zu einem string konvertiert werden soll
     * @return Subset als string-Repräsentation
     */
    static std::string toString(const NodeSubset& subset);

    /** Gibt einen TSPSolverKey als string-Repräsentation zurück
     *
     * @param tspSolverKey TSPSolverKey, welcher zu einem string konvertiert werden soll
     * @return TSPSolverKey als string-Repräsentation
     */
    static std::string toString(const TSPSolverKey& tspSolverKey);

public:
    TSPSolverDP(const Instance& instance) : TSPSolver(instance) {};
    ~TSPSolverDP() override = default;

    //Kommentar ggf. überarbeiten
    /** Löst das TSP auf gegebenem Cluster mit dynamischer Programmierung exakt.
     *
     * @param cluster Cluster, auf dem das TSP gelöst werden soll
     * @return TSPResult, welches das Cluster (in optimaler Reihenfolge) und die damit entstehenden Kosten enthält
     */
    Solution::Route solve(Instance::Cluster& cluster) override;
};

} // namespace ko::vrp
