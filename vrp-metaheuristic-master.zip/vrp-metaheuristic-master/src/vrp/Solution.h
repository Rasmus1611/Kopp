/**
* @file Solution.h
* @brief Abstrakte Klasse für die Lösungsrepresentation der Instanz
*
* @author Kurt Steinkamp, Julian Schmidt, Jannis Icken, Rasmus Henne
* @date 2025-03-14
 */

#pragma once
#include "Instance.hpp"


namespace ko::vrp {


class Solution {
public:
    enum ClusterSolverEnum {
        KMeans = 0,
        Hierarchical = 1,
        BinPacking = 2
    };

    struct Route {
        /// Cluster without DepotNode (always starts and ends at depot)
        Instance::Cluster cluster;

        /// overall TravelCost starting and ending an the depot
        Instance::TravelCost travelCost = 0;

        /// sum of all demands in the cluster
        Instance::Demand totalDemand = 0;
    };

    ClusterSolverEnum m_clusterSolver;

    bool m_improvementUsed;
    Instance::TravelCost m_improvementValue = 0;
    double m_durationImprovement = 0;

    double m_durationClustering = 0;
    double m_durationTSP = 0;

    // used for test runs
    bool m_isBestSolution = false;

private:
    /// Die Instanz, zu welcher die Lösung gehört
    Instance const* m_instance;

    /// Die Routen der Lösung
    std::vector<Route> m_routes;

public:

    /// Konstruktor
    explicit Solution(const Instance& instance)
      : m_instance(&instance) {};

    /** Constructs a Solution from a given solution file.
     *
     * @param instance Instance which contains the nodes.
     * @param filename Path to solution file.
     */
    explicit Solution(const Instance& instance, const std::string& filename);

    /// Destruktor
    ~Solution() = default;

    void setClusterSolver(const ClusterSolverEnum clusterSolver) {
        m_clusterSolver = clusterSolver;
    };

    void setImprovementUsed(const bool improvementUsed) { m_improvementUsed = improvementUsed; };

    void setDurationClustering(const double duration) { m_durationClustering = duration; };
    void setDurationImprovement(const double duration) { m_durationImprovement = duration; };
    void setDurationTSP(const double duration) { m_durationTSP = duration; };

    void setImprovementValue(const Instance::TravelCost improvement) { m_improvementValue = improvement; };

    void setIsBestSolution(const bool isBestSolution) { m_isBestSolution = isBestSolution; };

    /** Gibt den aktuellen Zielfunktionswert der Lösung zurück.
     *
     * @return Die Summe der Reisekosten aus den aktuell gespeicherten m_routes
     */
    [[nodiscard]] Instance::TravelCost getTotalTravelCost() const;

    /**
     * @brief Gibt die aktuell gespeicherte Route zurück
     * @return Referenz auf die aktuell gespeicherten Routen
     */
    std::vector<Route>& getRoutes() { return m_routes; };

    /**
     * @brief Überschreibt die aktuell gespeicherten Routen mit den Routen im Parameter. Erstellt eine deep-copy der Routen im Parameter.
     * @param routes Routen, welche gespeichert werden sollen
     */
    void setRoutes(const std::vector<Route>& routes);

    /**
     * @brief Fügt ein Cluster zur Solution hinzu
     * @param cluster Cluster, welches hinzugefügt werden soll
     */
    void addCluster(const Instance::Cluster& cluster);

    /**
     * @brief Stellt die Lösung graphisch dar (mithilfe der matplotlib-cpp Bibliothek)
     * @param showNodeIds true wenn die NodeIds im Plot dargestellt werden sollen, false sonst
     * @param showTravelCosts true wenn die TravelCosts im Plot dargestellt werden sollen, false sonst
     */
    void plot(bool showNodeIds, bool showTravelCosts);

    /**
     * @brief Gibt zurück, ob die Lösung zulässig ist.
     * @return true wenn die Lösung zulässig ist, false sonst
     */
    [[nodiscard]] bool isFeasible() const;

    /**
     * @brief Gibt die Lösung als string auf der Konsole aus
     */
    [[nodiscard]] std::string print() const;

    [[nodiscard]] std::string getClustersAsString() const;
};

} // namespace ko::vrp