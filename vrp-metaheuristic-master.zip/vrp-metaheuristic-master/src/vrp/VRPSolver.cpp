#include "VRPSolver.h"
#include "util/Timer.hpp"
#include "vrp/Clustering/BinPackingClusterSolver.h"
#include "vrp/Clustering/ClusterImprovement.h"

namespace ko::vrp {

bool VRPSolver::runClusterSolver() {
    INFO("Starte ClusterSolver");

    if (dynamic_cast<KmeansClusterSolver*>(m_clusterSolver.get())) {
        m_solution.setClusterSolver(Solution::ClusterSolverEnum::KMeans);
    } else if (dynamic_cast<HierarchicalClusterSolver*>(m_clusterSolver.get())) {
        m_solution.setClusterSolver(Solution::ClusterSolverEnum::Hierarchical);
    } else if (dynamic_cast<BinPackingClusterSolver*>(m_clusterSolver.get())) {
        m_solution.setClusterSolver(Solution::ClusterSolverEnum::BinPacking);
    }

    ko::Timer clusterTimer;
    Solution solution = m_clusterSolver->solve();
    m_solution.setDurationClustering(clusterTimer.elapsedSeconds());
    INFO("Clustering beendet nach: " + std::to_string(clusterTimer.elapsedSeconds()) + " Sekunden");

    m_solution.setRoutes(solution.getRoutes());

    if (m_solution.isFeasible())
        return true;

    return false;
}

Solution VRPSolver::solve(bool useImprovement) {

    m_solution.setImprovementUsed(useImprovement);


    // Basierend auf der durchschnittlichen Cluster-Größe, wählte TSPSolver Heuristik oder exakt
    if (m_instance.getNumberNodes() / m_instance.getNumberVehicles() >= TSP_THRESHOLD) {
        m_tspSolver = std::make_unique<TSPSolverHeuristic>(m_instance);
    }
    else {
        m_tspSolver = std::make_unique<TSPSolverDP>(m_instance);
    }

    // Cluster lösen
    const bool clusteringSuccessful = runClusterSolver();

    if (!clusteringSuccessful)
        return m_solution;

    // berechne clusterDemands für ClusterImprovement
    size_t maxClusterSize = 0;
    for (Solution::Route& route : m_solution.getRoutes()) {
        route.totalDemand = ClusterSolver::computeClusterDemand(m_instance, route.cluster);
        if (route.cluster.size() > maxClusterSize)
            maxClusterSize = route.cluster.size();
    }

    // Cluster Improvement
    if (useImprovement) {
        INFO("Starte ClusterImprovement");
        ko::Timer improvementTimer;

        ko::vrp::ClusterImprovement clusterImprovement(m_instance);
        const Instance::TravelCost improvement = clusterImprovement.runImprovement(m_solution, maxClusterSize);
        m_solution.setImprovementValue(improvement);

        m_solution.setDurationImprovement(improvementTimer.elapsedSeconds());
        INFO("ClusterImprovement beendet nach: " + std::to_string(improvementTimer.elapsedSeconds()) + " Sekunden");
    }

    // TSP lösen
    INFO("Starte TSPSolverDP");
    ko::Timer tspTimer;

    std::vector<Solution::Route>& routes = m_solution.getRoutes();
    for (auto& route : routes) {
        route = m_tspSolver->solve(route.cluster);
        route.totalDemand = ClusterSolver::computeClusterDemand(m_instance, route.cluster);
    }

    m_solution.setDurationTSP(tspTimer.elapsedSeconds());
    INFO("TSP beendet nach: " + std::to_string(tspTimer.elapsedSeconds()) + " Sekunden");

    return m_solution;
}

} // namespace ko::vrp