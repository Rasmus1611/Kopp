#include "../util/Logger.hpp"
#include "Instance.hpp"
#include "Solution.h"

/** Benutzung:
 *
 * Datei mit Solution erstellen, folgendes Format:
 * {12, 1, 16, 30}{28, 11, 4, 23, 2, 3, 6}{27, 24, 14}{20, 5, 25, 10, 15, 22, 9, 8, 18, 29}{21, 31, 19, 17, 13, 7, 26}
 *
 * Jede Menge {} repräsentiert ein Cluster, die Reihenfolge der NodeIds ist die richtige Reihenfolge der Route.
 *
 * Jetzt
 * ./plotSolution <Pfad der Instanz> <Pfad der Solution-Datei>
 * aufrufen.
 *
 */

int main(int argc, char** argv) {
    auto log = ko::Logger("PlotSolution");

    if (argc != 3) {
        log.ERROR("usage: ./plotSolution <instance-path> <solution-path>");
        return EXIT_FAILURE;
    }

    const auto instanceFilename = std::string(argv[1]);
    const auto instance = ko::vrp::Instance(instanceFilename);

    const auto solutionFilename = std::string(argv[2]);
    auto solution = ko::vrp::Solution(instance, solutionFilename);

    solution.print();

    solution.plot(false, false);

    return EXIT_SUCCESS;
}